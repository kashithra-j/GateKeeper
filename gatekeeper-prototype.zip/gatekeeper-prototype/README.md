# GATEKEEPER prototype

Run (Node 18+, no npm install needed):

    node server.js      # then open http://localhost:3000

- `server.js` holds the demo data, the policy engine (P1–P7) and the REST API.
- `public/index.html` is the UI; it loads everything from the API.

API: `GET /api/meta`, `GET /api/requests`, `POST /api/requests`, `POST /api/requests/:id/decision` (`{approver, decision}`).

Limits: in-memory data (resets on restart); the approver name is sent by the client, so this is NOT real authentication; risk scores are a simple additive heuristic, not an ML model.
