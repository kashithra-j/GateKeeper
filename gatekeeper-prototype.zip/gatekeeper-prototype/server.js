// GATEKEEPER prototype backend: zero dependencies (Node 18+). Data is in memory and resets on restart.
const http=require("http"),fs=require("fs"),path=require("path");
const PORT=process.env.PORT||3000;
const EMP=[{n:"Meera Iyer",r:"AP analyst"},{n:"Daniel Okafor",r:"Treasury analyst"},{n:"Priya Raman",r:"Finance manager"}];
const CRED=[
 {id:"AP Service Key",st:"Active",scopes:["payments:create","invoices:read"],limit:10000},
 {id:"Treasury Key",st:"Active",scopes:["payments:create","payments:wire","invoices:read"],limit:50000},
 {id:"Contractor Key",st:"Expiring in 6 days",scopes:["payments:create"],limit:5000},
 {id:"Legacy Vendor Key",st:"Expired",scopes:["payments:create"],limit:5000},
 {id:"Former Employee Key",st:"Revoked",scopes:["payments:create","payments:wire"],limit:20000}];
const SUP=[{n:"Northwind Logistics",t:"Verified"},{n:"Aster Components",t:"Verified"},{n:"Kestrel Freight",t:"New (under 30 days)"},{n:"Blue Harbor Trading",t:"Flagged"}];
const ACT=[{n:"Create payment",s:"payments:create"},{n:"Wire transfer",s:"payments:wire"},{n:"Read invoices",s:"invoices:read"},{n:"Update bank details",s:"suppliers:write"}];
const POL={P1:"Credential must be active",P2:"Scope must be granted to credential",P3:"Supplier must not be flagged",P4:"Amount above credential limit needs manager approval",P5:"New supplier above 5,000 needs manager approval",P6:"High risk score needs manager approval",P7:"Within limits: auto-approve"};
const money=n=>"$"+Number(n).toLocaleString("en-US");
const cls=r=>r<30?"Low":r<60?"Medium":"High";

function evaluate(q){
 const c=CRED.find(x=>x.id===q.cred),s=SUP.find(x=>x.n===q.sup);
 const credOk=c.st==="Active"||c.st.startsWith("Expiring"),supOk=s.t!=="Flagged",scopeOk=c.scopes.includes(q.scope);
 const overLimit=q.amt>c.limit,newBig=s.t.startsWith("New")&&q.amt>5000;
 const f=[["Amount ("+money(q.amt)+")",Math.min(40,Math.round(q.amt/1500))],
  ["Supplier trust ("+s.t+")",s.t==="Verified"?0:s.t.startsWith("New")?18:35],
  ["Credential state ("+c.st+")",credOk?(c.st==="Active"?0:8):45],
  ["Scope mismatch",scopeOk?0:22],
  ["Urgency wording in description",/urgent|override|asap|bypass/i.test(q.desc)?10:0]];
 const risk=Math.min(100,5+f.reduce((a,x)=>a+x[1],0));
 let st,pol,why;
 if(!credOk){st="Blocked";pol="P1";why=`${q.cred} is ${c.st.toLowerCase()}, so the gate stops the request before any approval is considered.`}
 else if(!supOk){st="Blocked";pol="P3";why=`${q.sup} is flagged in the supplier registry. Payments to flagged suppliers are blocked.`}
 else if(!scopeOk){st="Rejected";pol="P2";why=`${q.cred} does not hold the ${q.scope} scope needed for “${q.act}”.`}
 else if(overLimit){st="Pending approval";pol="P4";why=`${money(q.amt)} is above this credential’s ${money(c.limit)} limit. A manager must approve.`}
 else if(newBig){st="Pending approval";pol="P5";why=`${q.sup} is a new supplier and the amount is above 5,000. A manager must approve.`}
 else if(risk>=60){st="Pending approval";pol="P6";why=`Risk score ${risk} is High, so a manager must approve.`}
 else{st="Approved";pol="P7";why="Credential, scope, supplier and amount are all within policy. No approval needed."}
 const checks=[[credOk?"y":"n","Credential status",c.st],[scopeOk?"y":"n","Permission / scope",scopeOk?q.scope+" granted":q.scope+" not granted"],[supOk?(s.t==="Verified"?"y":"w"):"n","Supplier registry",s.t],[overLimit?"w":"y","Credential limit",money(q.amt)+" of "+money(c.limit)],[risk<60?"y":"w","Risk score",risk+" ("+cls(risk)+")"]];
 return {st,pol,why,risk,checks,factors:f,cred:c.st,needs:st==="Pending approval"};
}

let seq=1001;
function record(q,time,seed){const res=evaluate(q);return {id:"REQ-"+(seq++),time,emp:q.emp,cred:q.cred,sup:q.sup,act:q.act,amt:q.amt,scope:q.scope,desc:q.desc+(seed?" (seed data)":""),st:res.st,risk:res.risk,pol:res.pol,res}}
const log=[
 ["09:02","Meera Iyer","AP Service Key","Northwind Logistics","Create payment",4200,"payments:create"],
 ["09:15","Daniel Okafor","Treasury Key","Aster Components","Wire transfer",38000,"payments:wire"],
 ["09:41","Meera Iyer","Legacy Vendor Key","Northwind Logistics","Create payment",1800,"payments:create"],
 ["10:05","Daniel Okafor","Treasury Key","Kestrel Freight","Wire transfer",22000,"payments:wire"],
 ["10:22","Meera Iyer","AP Service Key","Blue Harbor Trading","Create payment",9500,"payments:create"],
 ["10:48","Meera Iyer","AP Service Key","Aster Components","Wire transfer",6000,"payments:wire"],
 ["11:10","Daniel Okafor","Former Employee Key","Aster Components","Wire transfer",15000,"payments:wire"],
 ["11:32","Meera Iyer","AP Service Key","Northwind Logistics","Create payment",2600,"payments:create"],
 ["11:57","Meera Iyer","AP Service Key","Northwind Logistics","Create payment",18500,"payments:create"],
 ["12:20","Daniel Okafor","Treasury Key","Aster Components","Create payment",7300,"payments:create"],
].map(a=>record({emp:a[1],cred:a[2],sup:a[3],act:a[4],amt:a[5],scope:a[6],desc:"Seed request"},a[0],true));

const send=(res,code,obj)=>{res.writeHead(code,{"Content-Type":"application/json"});res.end(JSON.stringify(obj))};
const body=req=>new Promise((ok,no)=>{let d="";req.on("data",c=>{d+=c;if(d.length>10000){no(new Error("Body too large"));req.destroy()}});req.on("end",()=>{try{ok(JSON.parse(d||"{}"))}catch{no(new Error("Invalid JSON"))}})});

http.createServer(async(req,res)=>{
 const url=new URL(req.url,"http://x");
 try{
  if(req.method==="GET"&&url.pathname==="/api/meta")return send(res,200,{emp:EMP,cred:CRED,sup:SUP,act:ACT,pol:POL});
  if(req.method==="GET"&&url.pathname==="/api/requests")return send(res,200,log);
  if(req.method==="POST"&&url.pathname==="/api/requests"){
   const b=await body(req),amt=Number(b.amt),desc=String(b.desc||"").trim();
   const ok=EMP.some(x=>x.n===b.emp)&&CRED.some(x=>x.id===b.cred)&&SUP.some(x=>x.n===b.sup)&&ACT.some(x=>x.n===b.act)&&ACT.some(x=>x.s===b.scope);
   if(!ok)return send(res,400,{error:"Unknown employee, credential, supplier, action or scope."});
   if(!(amt>0&&amt<=1e9))return send(res,400,{error:"Amount must be greater than 0."});
   if(desc.length<5||desc.length>500)return send(res,400,{error:"Description must be 5 to 500 characters."});
   const e=record({emp:b.emp,cred:b.cred,sup:b.sup,act:b.act,amt,scope:b.scope,desc},new Date().toTimeString().slice(0,5));
   log.push(e);return send(res,201,e);
  }
  const m=url.pathname.match(/^\/api\/requests\/(REQ-\d+)\/decision$/);
  if(req.method==="POST"&&m){
   const b=await body(req),e=log.find(x=>x.id===m[1]),who=EMP.find(x=>x.n===b.approver);
   if(!e)return send(res,404,{error:"Request not found."});
   if(e.st!=="Pending approval")return send(res,409,{error:"Request is not pending approval."});
   if(!who||who.r!=="Finance manager")return send(res,403,{error:"Only a finance manager can decide."});
   if(who.n===e.emp)return send(res,403,{error:"Separation of duties: approvers cannot decide their own request."});
   if(!["Approved","Rejected"].includes(b.decision))return send(res,400,{error:"Decision must be Approved or Rejected."});
   e.st=b.decision;e.desc+=" | "+b.decision.toLowerCase()+" by "+who.n;return send(res,200,e);
  }
  if(req.method==="GET"){
   const f=path.join(__dirname,"public",url.pathname==="/"?"index.html":path.normalize(url.pathname).replace(/^(\.\.[\/\\])+/,""));
   if(f.startsWith(path.join(__dirname,"public"))&&fs.existsSync(f)&&fs.statSync(f).isFile()){res.writeHead(200,{"Content-Type":f.endsWith(".html")?"text/html":"text/plain"});return fs.createReadStream(f).pipe(res)}
  }
  send(res,404,{error:"Not found"});
 }catch(err){send(res,400,{error:err.message})}
}).listen(PORT,()=>console.log("GATEKEEPER prototype on http://localhost:"+PORT));
